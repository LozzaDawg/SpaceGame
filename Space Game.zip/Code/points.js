



console.log('Points data processed.')
