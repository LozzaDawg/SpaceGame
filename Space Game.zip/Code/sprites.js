
var spaceShipSpr = new Image()
spaceShipSpr.src = 'Images/spaceship.png'

console.log('Sprite data processed.')
